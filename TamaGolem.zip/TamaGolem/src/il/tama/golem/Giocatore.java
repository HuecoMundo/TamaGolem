package il.tama.golem;

import java.util.ArrayList;
/**
 * la classe giocatore crea un allenatore di TamaGolem sulla base del nome
 * contiene una lista di TamaGolem
 * @author Axel Mastroianni Matteo Terzi Moussa
 *
 */
public class Giocatore {
	private String nome="";
	private ArrayList<TamaGolem> iMieiTamagolem=new ArrayList<TamaGolem>();
	/**
	 * costruttore
	 * @param nome
	 */
	public Giocatore(String nome) {
		if(!nome.equals(""))
			this.nome=nome;
	}
	/**
	 * evoca il TamaGolem dando per scontato che l'evocazione segua il principio: FIFO
	 * @return il TamaGolem evocato
	 */
	public TamaGolem evocaTamaGolem() {
		return iMieiTamagolem.get(0);
	}
	/**
	 * aggiunge alla lista di TamaGolem un nuovo TamaGolem creandolo sulla base del nome
	 * e della vita
	 * @param nome
	 */
	public void aggiungiTamaGolem(String nome) {
		iMieiTamagolem.add(new TamaGolem(nome,TamaGolem.VITA_MASSIMA));
	}
	/**
	 * verifica se un giocatore ha ancora TamaGolem, in caso contrario perde
	 * @return true or false se non ne ha pi� o se ne ha ancora
	 */
	public boolean haiPerso() {
		if(iMieiTamagolem.isEmpty())
			return true;
		return false;
	}
	/**
	 * ritorna il TamaGolem all'indice indicato
	 * @param indice
	 * @return TamaGolem alla posizione desiderata
	 */
	public TamaGolem getTamaGolem(int indice) {
		if(indice>=0)
			return iMieiTamagolem.get(indice);
		return null;
	}
	/**
	 * rimuove il TamaGolem quando muore
	 */
	public void rimuoviTamaGolem() {
		iMieiTamagolem.remove(0);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if(!nome.equals(""))
			this.nome = nome;
	}
	/**
	 * 
	 * @return numero TamaGolem ancora in possesso dall'allenatore
	 */
	public int getNumeroTamaGolem() {
		return iMieiTamagolem.size();
	}

}
