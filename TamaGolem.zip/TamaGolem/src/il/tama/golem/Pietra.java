package il.tama.golem;
/**
 * 
 * @author Axel Mastroianni Matteo Terzi Moussa
 * @version 1.0
 *
 */
public class Pietra {
	//enum con i nomi degli elementi presenti nel gioco
	public enum Elementi{ACQUA,ELETTRO,ERBA,FUOCO,PSICO,BUIO,VOLANTE,SPETTRO,COLEOTTERO,GHIACCIO};
	private int indice=0;//l'indice della pietra mi consente di recuperarla nell'enum
	
	public Pietra(int indice) {
		this.indice=indice;
	}
	public int getIndice() {
		return indice;
	}
	public void setIndice(int indice) {
		if(indice>0)
			this.indice = indice;
	}

}
