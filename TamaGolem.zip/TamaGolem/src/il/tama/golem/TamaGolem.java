package il.tama.golem;

import java.util.ArrayList;

import il.tama.golem.Pietra.Elementi;
/**
 * classe per creare un TamaGolem
 * @author Axel Mastroianni Matteo Terzi Moussa
 * @version 1.0
 *
 */
public class TamaGolem {
	public static final int VITA_MASSIMA=100;//cos� la partita � pi� "avvincente"
	private String nome="";
	private ArrayList<Pietra> pietre=new ArrayList<Pietra>(); //le pietre che gli vado a caricare
	Elementi element;
	private int vita=0;
	/**
	 * costruttore per creare un TamaGolem con vita
	 * @param nome
	 * @param vita
	 */
	public TamaGolem(String nome, int vita) {
		if(!nome.equals(""))
			this.nome=nome;
		if(vita>=0)
			this.vita=vita;
	}
	/**
	 * costruttore per creare un TamaGolem senza vita
	 * @param nome
	 */
	public TamaGolem(String nome) {
		this.nome=nome;
	}
	/**
	 * questo metodo consente al TamaGolem di scagliare un attacco scegliendo una pietra
	 * all'indice indicato solo tra quelle disponibili
	 * @param indice
	 * @return la pietra all'indice indicato
	 */
	public Pietra attacca(int indice) {
		if(indice>=0 && indice<pietre.size()) //evito la nullptr exception, o almeno la giustifico
			return pietre.get(indice);
		return null;
	}
	/**
	 * il TamaGolem subisce dei danni
	 * @param danno
	 */
	public void subisci(int danno) {
		if(danno>=0)
			setVita(Math.max(vita-danno, 0)); //la vita non va sotto zero
	}
	/**
	 * verifica se il TamaGolem � vivo
	 * @return true or false	in base alla sua vita
	 */
	public boolean sonoMorto() {
		if(vita==0)
			return true;
		return false;
	}
	/**
	 * aggiunge una pietra al TamaGolem solo se presente nell'enum, altrimenti il
	 *  programma da errore
	 *  Domanda: come si fa a creare un messaggio proprio di errore senza che il programma
	 *  mostri quelle orribili scritte rosse che ti costringono a far ripartire tutto?
	 * @param nomePietra
	 */
	public void aggiungiPietra(String nomePietra) {
		pietre.add(new Pietra(element.valueOf(nomePietra.toUpperCase()).ordinal()));
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if(!nome.equalsIgnoreCase(""))
			this.nome = nome;
	}

	public ArrayList<Pietra> getPietre() {
		return pietre;
	}

	public int getVita() {
		return vita;
	}

	public void setVita(int vita) {
		if(vita>=0)
			this.vita = vita;
	}

	public Elementi getElement() {
		return element;
	}
}
