package il.tama.golem;

import java.util.ArrayList;
/**
 * si svolge la battaglia tra due TamaGolem
 * @author Axel Mastroianni Matteo Terzi Moussa
 * @version 1.0
 *
 */
public class Battaglia {
	private Giocatore giocatore1;
	private Giocatore giocatore2;
	private int numeroElementi=0;
	private Equilibrio tabellone;
	private int numeroPietre=0;
	private int numeroTamaGolem=0;
	private int scortaPietre=0;
	/**
	 * inizializzo un'oggetto battaglia andando a settare l'equilibrio, poi calcola
	 * G,P ed S sulla base delle formule presentate nelle slide
	 * @param giocatore1
	 * @param giocatore2
	 * @param numeroElementi
	 */
	public Battaglia(Giocatore giocatore1, Giocatore giocatore2, int numeroElementi) {
		this.giocatore1=giocatore1;
		this.giocatore2=giocatore2;
		this.numeroElementi=numeroElementi;
		tabellone=new Equilibrio("Tentacolo",numeroElementi);
		tabellone.creaEquilibrio();
		numeroPietre=((numeroElementi+1)/3)+1;//P
		numeroTamaGolem=(numeroElementi-1)*(numeroElementi-2)/(2*numeroPietre);//G
		scortaPietre=((2*numeroTamaGolem*numeroPietre)/numeroElementi)*numeroElementi;//S
	}
	
	public Giocatore getGiocatore1() {
		return giocatore1;
	}

	public void setGiocatore1(Giocatore giocatore1) {
		if(giocatore1!=null)
			this.giocatore1 = giocatore1;
	}

	public Giocatore getGiocatore2() {
		return giocatore2;
	}

	public void setGiocatore2(Giocatore giocatore2) {
		if(giocatore2!=null)
			this.giocatore2 = giocatore2;
	}

	public int getNumeroElementi() {
		return numeroElementi;
	}

	public void setNumeroElementi(int numeroElementi) {
		if(numeroElementi>=3)
			this.numeroElementi = numeroElementi;
	}

	public Equilibrio getTabellone() {
		return tabellone;
	}

	public int getNumeroPietre() {
		return numeroPietre;
	}

	public void setNumeroPietre(int numeroPietre) {
		if(numeroPietre>0)
			this.numeroPietre = numeroPietre;
	}

	public int getNumeroTamaGolem() {
		return numeroTamaGolem;
	}

	public void setNumeroTamaGolem(int numeroTamaGolem) {
		if(numeroTamaGolem>0)
			this.numeroTamaGolem = numeroTamaGolem;
	}

	public int getScortaPietre() {
		return scortaPietre;
	}

	public void setScortaPietre(int scortaPietre) {
		if(scortaPietre>0)
			this.scortaPietre = scortaPietre;
	}

	/**
	 * questo metodo rappresenta la battaglia tra due TamaGolem: ognuno scaglia una pietra
	 * poi tramite il metodo chiVince del tabellone stabilisce la vittoria di una pietra 
	 * sull'altra. Sulla base di ci� il TamaGolem perdente subisce danni
	 * Nota: per "abbellire"(secondo noi) il programma abbiamo implementato la stampa a video
	 * dei danni subiti dal TamaGolem e il tipo di pietra che lo colpisce. Inoltre il metodo
	 * attendi lascia passare 2 secondi prima di passare al turno successivo in modo 
	 * da dare il tempo agli utenti di leggere i dati
	 * @param indicePietra
	 * @param tama1
	 * @param tama2
	 */
	public void battlePhase(int indicePietra, TamaGolem tama1, TamaGolem tama2) {
		Pietra p1=tama1.attacca(indicePietra);
		Pietra p2=tama2.attacca(indicePietra);
		if(tabellone.chiVince(p1.getIndice(), p2.getIndice())) {
			int quantoPerde=tabellone.setPotenzaPietra(p1.getIndice(), p2.getIndice());
			tama2.subisci(quantoPerde);
			System.out.println(tama2.getNome()+" subisce un attacco "+tama1.getElement().values()[p1.getIndice()]);
			System.out.println("E perde "+quantoPerde);
			attendi(2);
		}
		else {
			int quantoPerde=tabellone.setPotenzaPietra(p2.getIndice(), p1.getIndice());
			tama1.subisci(quantoPerde);
			System.out.println(tama1.getNome()+" subisce un attacco "+tama2.getElement().values()[p2.getIndice()]);
			System.out.println("E perde "+quantoPerde);
			attendi(2);
		}
	}
	/**
	 * verifica se il TamaGolem in campo per il giocatore1 � esausto
	 * @return true or false se true allora lo rimuove dalla lista dei TamaGolem 
	 * altrimenti continua la battaglia
	 */
	public boolean endPhaseGiocatore1() {
		if(giocatore1.getTamaGolem(0).sonoMorto()) {
			giocatore1.rimuoviTamaGolem();
			return true;
		}
		return false;	
	}
	/**
	 * stessa cosa del giocatore1
	 * @return true or false
	 */
	public boolean endPhaseGiocatore2() {
		if(giocatore2.getTamaGolem(0).sonoMorto()) {
			giocatore2.rimuoviTamaGolem();
			return true;
		}
		return false;
	}
	/**
	 * verifica se il giocatore1 ha perso
	 * @return true or false
	 */
	public boolean sconfittaGicoatore1() {
		if(giocatore1.haiPerso())
			return true;
		return false;
	}
	/**
	 * stessa cosa del giocatore1
	 * @return true or false
	 */
	public boolean sconfittaGiocatore2() {
		if(giocatore2.haiPerso())
			return true;
		return false;
	}
	/**
	 * questo metodo verifica se due TamaGolem hanno le stesse pietre in modo da evitare
	 * l'inizio di un'eterna battaglia
	 * @param tama1
	 * @param tama2
	 * @return true or false
	 */
	public boolean stessePietre(ArrayList<Pietra>tama1, ArrayList<Pietra>tama2) {
		int contaUguali=0;
		for(int i=0;i<tama1.size();i++) {
			if(tama1.get(i).getIndice()==tama2.get(i).getIndice())
				contaUguali++;
		}
		if(contaUguali==tama1.size())
			return true;
		return false;
	}
	/**
	 * attende due secondi 
	 * @param secondi
	 */
	public void attendi(int secondi) {
		try {
			Thread.sleep(secondi*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
